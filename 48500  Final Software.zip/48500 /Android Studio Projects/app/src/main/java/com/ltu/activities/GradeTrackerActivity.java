package com.ltu.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class GradeTrackerActivity extends AppCompatActivity {
    private Button setGoalButton;
    private TextView goalStatusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade_tracker);

        setGoalButton = findViewById(R.id.setGoalButton);
        goalStatusTextView = findViewById(R.id.goalStatusTextView);

        setGoalButton.setOnClickListener(view -> {
            // Implement goal-setting logic
            goalStatusTextView.setText("Goal Achieved!");
        });
    }
}
