package com.ltu.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AcademicProgressActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_academic_progress);

        // Implement logic to show weekly progress and completed tasks
    }
}
