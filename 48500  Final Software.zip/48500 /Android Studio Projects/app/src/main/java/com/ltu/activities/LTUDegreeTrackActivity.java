package com.ltu.activities;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class LTUDegreeTrackActivity extends AppCompatActivity {
    private Button degreeTrackButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ltu_degree_track);

        degreeTrackButton = findViewById(R.id.degreeTrackButton);

        degreeTrackButton.setOnClickListener(view -> {
            // Start Degree Classification Tracking or simulation
        });
    }
}
