package com.ltu.utils;

public class GradeTracker {

    private float targetGrade;
    private float currentGrade;

    public GradeTracker(float targetGrade) {
        this.targetGrade = targetGrade;
        this.currentGrade = 0;
    }

    public void setCurrentGrade(float currentGrade) {
        this.currentGrade = currentGrade;
    }

    public String checkGoalStatus() {
        if (currentGrade >= targetGrade) {
            return "Goal Achieved!";
        } else {
            return "Keep Going! You are " + (targetGrade - currentGrade) + " points away from your goal.";
        }
    }

    public void resetGoal() {
        this.currentGrade = 0;
    }
}
