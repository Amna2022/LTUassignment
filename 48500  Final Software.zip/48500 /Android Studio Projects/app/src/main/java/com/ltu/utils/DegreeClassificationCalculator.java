package com.ltu.utils;

public class DegreeClassificationCalculator {

    public static String calculateDegreeClassification(float grade) {
        if (grade >= 70) {
            return "First Class";
        } else if (grade >= 60) {
            return "Upper Second Class";
        } else if (grade >= 50) {
            return "Lower Second Class";
        } else if (grade >= 40) {
            return "Third Class";
        } else {
            return "Fail";
        }
    }

    public static String calculateDegreeClassification(float grade, String level) {
        // Additional logic can be implemented here based on level (UG, PG, etc.)
        return calculateDegreeClassification(grade);
    }
}
